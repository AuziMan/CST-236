<?php

class SecurityService{
    private $username = "";
    private $password = "";
    
    function __construct($username, $password){
        $this->username = $username;
        $this->password = $password;
    }
    
    public function authenticate(){
        if($this->password == " " || $this->username == " "){
            return false;
        }
        if($this->password == "qwerty" && $this->username == "auzi"){
            return true;
        }
        else{
            return false;
        }
    }
}