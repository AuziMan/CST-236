<?php

require_once 'Dog.php';
require_once 'Cat.php';

$cat1 = new Cat("Morris", "Orange");

$dog1 = new dog("Fido", "Black");

$cat1->talk();
$dog1->talk();

$dog1->doTrick();
$cat1->doTrick();