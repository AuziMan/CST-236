<?php
require_once 'Animal.php';

class Cat extends Animal{
    public function talk()
    {
        Echo "meow<br>";
    }
    public function doTrick()
    {
        echo "Cat does not listen";
    }

    

    
}