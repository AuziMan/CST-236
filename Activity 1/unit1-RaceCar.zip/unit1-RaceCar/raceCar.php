<?php

class Car{
    

    private $tires;
    private $hasEngin;
    private $tirePressure;
    private $isRunning;
    private $SpeedofCar;
    
    //Adding tires
    public function addTires($numberOfTires) {
        if($numberOfTires > 0 && $numberOfTires <= 4)
        {
            if($this->tires + $numberOfTires > 4){
                echo "You have the max number of tires";
            }
            else{
               $this->tires =$this->tires + $numberOfTires;
               echo "you installed " . $numberOfTires . " you have " . $this->tires .  " on your car<br>";
            }
        }
        else
        {
          echo "Add more tires<br>"; 
        }

  }
  
  
  //Inflating tires
  public function inflateTires($tirePSI){
      $this->tirePressure =$this->tirePressure + $tirePSI;
      
      if($tirePSI < 32 && $tirePSI > 50)
      {
          echo "Your tires are at " . $this->tirePressure . ". that is a dangerous psi. change the psi<br>";
      }
      else  
      {
          echo "Your tires are at " . $this->tirePressure . "psi. that is a good psi<br>";
      }
      
  }
  
  public  function checkEngin($hasEngin){
      if($hasEngin == false)
      {
        echo "You must have an engin in your car.<br>";
      }
      else
      {
        echo "Your car is ready to run!<br>";
      }
  }
  
  public function checkIfRunning($Running){
      if($Running == true && $this->tirePressure > 32)
      {
         echo "Your engin is running. Ready to drive!<br>";
         
      }
      else
      {
          echo "Your engine must be running in order to drive<br>";
      }  
      
  }
  
  public function carSpeed($Speed){
      $this->SpeedofCar = $this->SpeedofCar = $Speed;
      echo "you car is going " . $this->SpeedofCar . "MPH.";
  }
  
  
    
    
}


?>