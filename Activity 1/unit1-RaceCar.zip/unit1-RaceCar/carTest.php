<?php

require_once 'raceCar.php';

$raceCar = new Car();

$raceCar->addTires(4);
$raceCar->inflateTires(32);
$raceCar->checkEngin(true);
$raceCar->checkIfRunning(false);
$raceCar->carSpeed(60);
$raceCar->carSpeed(80);

