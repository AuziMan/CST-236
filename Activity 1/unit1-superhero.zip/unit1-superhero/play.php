<?php

error_reporting(E_ALL);
init_set('display_errors', 1);

require_once 'SuperHero.php';

$ultraMan = new SuperHero("Austin");
$unstopable = new SuperHero("Jacob");

while($ultraMan->isHeDead() == "alive" && $unstopable->isHeDead() == "alive")
{
    $ultraMan->attach($unstopable);
    echo $unstopable->getName() . " has " . $unstopable->getHealth() . " heal left <br> ";
    $unstopable->attach($ultraMan);
    echo $ultraMan->getName() . " has " . $ultraMan->getHealth() . "health if<br>";
    echo"<hr>";
}

if ($ultraMan->getHealth() > 0){
    echo "it look like " . $unstopable->getName() . " lost. <br>";
}
else{
    echo "it looks like " . $ultraMan->getName() . "was defeatd<br>";
}

?>

