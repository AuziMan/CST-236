<?php

class Person{
    
    // Proporties
    protected $name;
    private $age;
    private $username;
    private $password;
    private $job;
    private $car;
    private $shoes;
    
    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    //Construtor
    public function __construct($n)
    {
        $this->name = $n;
        echo "Hello. I'm a person. My name is " . $n . "<br>";
        $this->username = "bob";
        $this->password = "qwerty";
        $this->job = "grocer";
        $this->car = "Volkswagen";
        $this->shoes = "vans";
        
    }
    
    public function walk()
    {
        echo $this -> name . " is walking...<br>";
    }
    
    public function greeting() 
    {
     echo "Hello!<br>";
    }
    
    
    // formal greeting, say in brittish
    
    public function formalGreeting()
    {
       echo "Hello chap, my name is " . $this -> name . ". It is nice to meet you. Here, have some tea.<br>"; 
    }
    
    
    // spanish greeting
    public function spanishGreeting()
    {
        echo "Hola mi amigo, me llamo " . $this-> name . "<br>";
    }
    
    //login
    public function login($a, $b) 
    {
        if($a == $this->username && $b == $this->password )
        {
            echo "Horray! you are logged in. <br> ";
        }
        else
        {
           echo "Your username and password is wrong <br>";
        };
          
    }
    
    // job
    public function employment()
    {
     echo "hello! my job is a " . $this->job . "<br>";   
    }
    
    //car
    public function car() 
    {
      echo "hey! my name is " . $this->name . " want to go on a ride in my " . $this->car . "? <br>";   
    }
    
    public function shoes() 
    {
      echo "Hey! check out my new shoes! they are " . $this->shoes . "<br>";
    }
    
    
    
        
}




?>