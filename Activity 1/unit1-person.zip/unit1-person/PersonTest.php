<?php

require_once 'Person.php';

$person1 = new Person("Mark");

$person2 = new Person("Samuel");

$person3 = new Person("Austin");

$person1->walk();

$person2->walk();

$person1->greeting();


$person1->formalGreeting();

$person2->spanishGreeting();

$person2-> login("norman", "password");
$person2-> login("bob", "qwerty");

$person2->employment();

$person3->car();

$person3->shoes(); 

