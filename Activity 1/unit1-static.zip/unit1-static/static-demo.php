<?php

require_once 'User.php';

$pw = 'asdf';

$pw2 = 'akhakhfajhj';

if(User::validatePassword($pw)){
    echo "Password is long enough!<br>";
}
else{
    
    echo "Your password is too short<br>";
}